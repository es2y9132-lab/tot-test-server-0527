# TOT Test Server
트레이딩 교육 및 실시간 코인 차트 페이지

## 기능
- 실시간 트레이딩뷰 차트
- 코인 뉴스 관련 유튜브 영상 자동 업데이트

## 사용 방법
1. index.html 파일 수정 (유튜브 API 키 입력)
2. 웹 서버나 GitHub Pages에 업로드
